import React, { Component } from 'react';
import { Redirect } from 'react-router-dom'
import {
    Container,
    Button,
    Form,
    Row,
    Col
} from 'react-bootstrap';
import Navigation_Navber from '../../components/Navigation_Navber/Navigation_Navber'
import Footer from '../../components/Navigation_Navber/Footer'

class Member_Register extends React.Component {
    constructor(props) {
        super(props)
        // 這個狀態只是決定要不要重新導向
        this.state = {
            email: '',
            password: '',
            name: '',
            id_card: '',
            birthday: '',
            mobile: '',
            address: '',
            users: [],
            error: null,
            redirectToReferrer: false,
        }
    }

    clickMember = () => {
        // 檢查寫這裡
        if (!this.state.password) {
            alert('密碼為必填！')
            return
        }
        if (!this.state.name) {
            alert('姓名為必填！')
            return
        }
        if (!this.state.id_card) {
            alert('身分證字號為必填！')
            return
        }
        if (!this.state.birthday) {
            alert('出生日期為必填！')
            return
        }
        if (!this.state.mobile) {
            alert('行動電話為必填！')
            return
        }
        if (!this.state.address) {
            alert('地址為必填！')
            return
        }
        // if (this.state.id_card !== /^[A-Za-z][12]\d{8}$/) {
        //     alert('請填寫正確的身分證字號')
        //     return
        // }


        const url = 'http://localhost:3000/users/?email=' + this.state.email + '&id_card=' + this.state.id_card
        this.requestToServer(url, 'GET', {}, this.click)
        //如果有找到就不要讓他post
    }

    postAddMember = () => {
        const url = 'http://localhost:8000/users'
        this.requestToServer(
            url,
            'post',
            {
                email: this.state.email,
                password: this.state.password,
                name: this.state.name,
                id_card: this.state.id_card,
                birthday: this.state.birthday,
                mobile: this.state.mobile,
                address: this.state.address,
            },
            // this.signup
            alert('註冊成功!')
        )
    }

    requestToServer = (url, method, data = {}, callback) => {
        // GET方法不有body，先設定出樣版物件
        const requestTemplate = new Request(url, {
            method: method,
            headers: new Headers({
                Accept: 'application/json',
                'Content-Type': 'application/json',
            }),
        })

        let req = requestTemplate

        // 如果不是GET再加上body
        if (method !== 'GET')
            req = new Request(requestTemplate, { body: JSON.stringify(data) })

        fetch(req)
            .then(response => {
                // 直接轉換JSON格式為物件、字串、數字…
                return response.json()
            })
            .then(jsonObject => {
                // jsonObject會是一個JavaScript物件
                console.log(jsonObject)
                if (method === 'GET') {
                    this.setState({
                        users: jsonObject
                    }, callback)
                }

            })
            .catch(error => {
                // Error
                this.setState({ result: error })
                console.log('錯誤訊息', error)
            })
    }

    click = () => {

        const userFindEmailIndex = this.state.users.findIndex(
            user => user.email === this.state.email
        )

        console.log('userFindEmailIndex', userFindEmailIndex)

        if (userFindEmailIndex !== -1) {
            alert('已註冊的帳號！')
            return
        }

        const userFindIdCardIndex = this.state.users.findIndex(
            user => user.id_card === this.state.id_card
        )

        console.log('userFindIdCardIndex', userFindIdCardIndex)

        if (userFindIdCardIndex !== -1) {
            alert('已註冊的ID CARD！')
            return
        }

        this.postAddMember()

    }

    // 可控元件通用
    handleChange = event => {
        this.setState({
            // 物件屬性由計算得來
            [event.target.name]: event.target.value,
        })
    }
    handleResetClick = (e) => {
        this.setState({
            email: '',
            password: '',
            name: '',
            id_card: '',
            birthday: '',
            mobile: '',
            address: '',
        })
    }

    render() {


        return (
            <>
                <Navigation_Navber />
                <div>
                    <Container>
                        <br />
                        <h1>註冊</h1>
                        <hr />
                        {/* 電子信箱 */}
                        <Form.Group as={Row} controlId="formHorizontalEmail">
                            <Form.Label column sm={2}>
                                Email
                            </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="email"
                                    placeholder="Email"
                                    value={this.state.email}
                                    name="email"
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 密碼 */}
                        <Form.Group as={Row} controlId="formHorizontalPassword">
                            <Form.Label column sm={2}>
                                Password
                            </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="password"
                                    placeholder="Password"
                                    value={this.state.password}
                                    name="password"
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 姓名 */}
                        <Form.Group as={Row} controlId="">
                            <Form.Label column sm={2}>
                                姓名
                            </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="text"
                                    placeholder="name"
                                    value={this.state.name}
                                    name="name"
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 性別 */}
                        {/* <fieldset>
                            <Form.Group as={Row}>
                                <Form.Label as="legend" column sm={2}>
                                    性別
                                </Form.Label>
                                <Col sm={10}>
                                    <Form.Check
                                        type="radio"
                                        label="男性"
                                        name="formHorizontalRadios"
                                        id="formHorizontalRadios1"
                                        value={this.state.m_sex}
                                        onChange={this.handleChange}
                                    />
                                    <Form.Check
                                        type="radio"
                                        label="女性"
                                        name="formHorizontalRadios"
                                        id="formHorizontalRadios2"
                                        value={this.state.m_sex}
                                        onChange={this.handleChange}
                                    />
                                </Col>
                            </Form.Group>
                        </fieldset> */}

                        {/* 身分證字號 */}
                        <Form.Group as={Row} controlId="formGridAddress1">
                            <Form.Label column sm={2}>
                                身分證字號
                             </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="text"
                                    placeholder="A123456789"
                                    name="id_card"
                                    value={this.state.id_card}
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 出生日期 maybe use datepicker  */}
                        <Form.Group as={Row} controlId="formGridAddress1">
                            <Form.Label column sm={2}>
                                出生年月日
                             </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="text"
                                    placeholder="2019-09-09"
                                    name="birthday"
                                    value={this.state.birthday}
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 行動電話 */}
                        <Form.Group as={Row} controlId="formGridAddress1">
                            <Form.Label column sm={2}>
                                行動電話
                            </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="text"
                                    placeholder="0999999999"
                                    value={this.state.mobile}
                                    name="mobile"
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>

                        {/* 地址 */}
                        <Form.Group as={Row} controlId="formGridAddress1">
                            <Form.Label column sm={2}>
                                地址
    </Form.Label>
                            <Col sm={10}>
                                <Form.Control
                                    type="text"
                                    name="address"
                                    placeholder="台北市中山區龍江路99巷99號"
                                    value={this.state.address}
                                    onChange={this.handleChange}
                                />
                            </Col>
                        </Form.Group>
                        <br />
                        <hr />

                        {/* 送出-清除 */}
                        <Form.Group as={Row}>
                            <Col sm={{ span: 4, offset: 2 }}>
                                <Button
                                    type="submit"
                                    style={{ 'margin-right': 20 }}
                                    onClick={this.clickMember}
                                >送出</Button>
                                <Button type="submit2"
                                    onClick={this.handleResetClick}
                                >重填</Button>
                                {/* 想設一個清除可是不清楚寫法 */}
                            </Col>
                        </Form.Group>



                    </Container>
                </div>
                <Footer />
            </>
        );
    }
}

export default Member_Register;