import React, { Component } from 'react';
import Carousel from '../components/Home/Carousel'
import Login_Page from '../components/Login_V/Login_Page'
import Footer from '../components/Navigation_Navber/Footer'
import {
  ListGroup,
  Container,
  Accordion,
  Button,
  Form,
  Card,
  Row,
  Col,
  Table,
  Nav,
  Tab,
  TabContainer,
  Tabs

} from 'react-bootstrap';
import { BrowserRouter as Router, Route, Link, NavLink, Switch,Redirect } from "react-router-dom"
import './../style/Login_V/Login_V.css'

class Login extends React.Component {
    constructor(props) {
      super(props)
      console.log(props.location)
      // 這個狀態只是決定要不要重新導向
      this.state = {
        users: [],
        error: null,
        redirectToReferrer: false,
        email: '',
        password: '',
      }
    }
    getUsersAndLogin = () => {
      // const url = 'http://localhost:5555/users'
      const url = 'http://localhost:3000/users'
      this.requestToServer(url, 'GET', {}, this.login)
    }
  
    requestToServer = (url, method, data = {}, callback) => {
      // GET方法不有body，先設定出樣版物件
      const requestTemplate = new Request(url, {
        method: method,
        headers: new Headers({
          Accept: 'application/json',
          'Content-Type': 'application/json',
        }),
      })
  
      let req = requestTemplate
  
      // 如果不是GET再加上body
      if (method !== 'GET')
        req = new Request(requestTemplate, { body: JSON.stringify(data) })
  
      fetch(req)
        .then(response => {
          // 直接轉換JSON格式為物件、字串、數字…
          return response.json()
        })
        .then(jsonObject => {
          // jsonObject會是一個JavaScript物件
          if (method === 'GET')
            this.setState(
              {
                users: jsonObject,
              },
              callback
            )
          console.log(jsonObject)
        })
        .catch(error => {
          // Error
          this.setState({ result: error })
          console.log('錯誤訊息', error)
        })
    }
  
    login = () => {
      if (!this.state.email) {
        alert('帳號為必填！')
        return
      }
  
      if (!this.state.password) {
        alert('密碼為必填！')
        return
      }
      // console.log(this.state)
      // console.log(typeof this.state.users)
  
      // 因為node express呈現的資料格式是users包users內的資料,故需要多包一層users ex: this.state.users.user
      // const userFindDataIndex = this.state.users.users.findIndex(
      const userFindDataIndex = this.state.users.findIndex(
        user => user.email === this.state.email
      )
      // console.log(userFindDataIndex)
  
      if (userFindDataIndex === -1) {
        alert('未註冊的帳號！')
        return
      }
  
      if (
        // this.state.users.users[userFindDataIndex].password !== this.state.password
        this.state.users[userFindDataIndex].password !== this.state.password
      ) {
        alert('密碼錯誤！')
        return
      }
      else{
        localStorage.setItem('member_sid',this.state.users[userFindDataIndex].member_sid)
        localStorage.setItem('member_name',this.state.users[userFindDataIndex].name)
        alert('登入成功！')
        }
  
      this.props.authenticate(() => {
        this.setState({ redirectToReferrer: true })
      })
      
    }
  
    // 可控元件通用
    handleChange = event => {
      this.setState({
        // 物件屬性由計算得來
        [event.target.name]: event.target.value,
      })
    }
  
    render() {
      let { from } = this.props.location.state || { from: { pathname: '/Member_information' } }
      let { redirectToReferrer } = this.state
  
      // 作重新導向，回到上一頁(如果有記錄的話)，或是首頁(如果沒記錄的話)
      if (redirectToReferrer) return <Redirect to={from} />
      // console.log(from)
      // console.log(redirectToReferrer)
      return (
        <>
          <Carousel />
         
         <div className='member-wrap' id=''>
         <div className='member-card_title'>
         Bistro 歡迎您</div>
         <input
           type="text"
          value={this.state.email}
          name="email"
          placeholder="帳號" 
          onChange={this.handleChange}
        />
         <input
          type="password"
          name="password"
          placeholder="密碼" 
          value={this.state.password}
          onChange={this.handleChange}
        />
    
                        <button onClick={this.getUsersAndLogin}>登入</button>
                      
                        <div className="social-login" >

                            <div className="deco " >使用其他帳號登入</div>
                            <button className="btn fb" >
                                <span className="social-icon fb" >fb</span></button>
                            <button className="btn line" ><span className="social-icon line"
                                    >line</span>
                            </button>
                            <br></br>
                            <div className="signup-link " ><a>還沒帳號？請註冊</a></div>
                        <Link to="Member_Register "> 註冊</Link>
                        </div>
                        
    </div>
 
        <Footer />
        </>
      )
    }
  }
  
  export default Login
  